import os
import time
from groq import Groq

# hagan una cuenta en https://groq.com/ y obtengan su API Key en https://console.groq.com/keys
API_KEY = "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"
client = Groq(api_key=API_KEY)

# Lista actualizada de figuras a generar
FIGURAS_A_GENERAR = [
    "Epífora", 
    "Anadiplosis", 
    "Epanadiplosis"
    ]

# LISTA DE MODELOS EN ORDEN DE PRIORIDAD
MODELOS_DISPONIBLES = [
    "llama-3.3-70b-versatile",
    "llama-3.1-70b-versatile",
    "mixtral-8x7b-32768",
    "gemma2-9b-it",
    "llama-3.1-8b-instant"
]

ARCHIVO_ENTRADA = "lote_001.txt"
CARPETA_SALIDA = "poemas_generados"

figuras_master = {
    "Epífora": "Repetición de una o varias palabras al final de versos o frases sucesivas para crear un eco rítmico.",
    "Anadiplosis": "Repetición de la última palabra de un verso al principio del verso siguiente, creando una cadena lógica.",
    "Epanadiplosis": "Consiste en comenzar y terminar un mismo verso con la misma palabra exacta.",
    "Bimembración": "Divide el verso en dos partes o miembros con estructuras gramaticales paralelas, pesos similares o simetría.",
    "Políptoton": "Uso de una misma palabra en diferentes formas gramaticales (cambio de género, número o tiempo verbal) en proximidad.",
    "Quiasmo": "Repetición de ideas o estructuras gramaticales de forma cruzada (esquema A-B, B-A) para invertir el sentido.",
    "Correlación": "Correspondencia término a término entre varios elementos repartidos a lo largo de los versos (ej: elementos A1, B1 y A2, B2).",
    "Apóstrofe": "Invocación o exclamación dirigida con vehemencia a un ser (real o imaginario), a una persona ausente o a un concepto abstracto.",
    "Hipérbaton": "Alteración del orden lógico y convencional de las palabras en la oración para dar énfasis o belleza estética.",
    "Anástrofe": "Inversión del orden natural de solo dos palabras consecutivas (por ejemplo, colocar el adjetivo antes del sustantivo de forma extrema).",
    "Elipsis": "Omisión intencionada de palabras que son necesarias gramaticalmente pero que se sobreentienden perfectamente por el contexto.",
    "Sinestesia": "Atribución de una sensación (olfato, gusto, tacto, vista, oído) a un concepto que no le corresponde (ej: 'ruido amarillo').",
    "Paranomasia": "Uso de palabras con sonidos muy similares (parónimos) pero cuyos significados son totalmente distintos.",
    "Diáfora": "Uso de una misma palabra con dos o más significados distintos dentro del mismo enunciado o estrofa.",
    "Calambur": "Juego de palabras que consiste en modificar el significado de una palabra o frase agrupando sus sílabas de modo distinto."
}

prompt_template = """
Eres un poeta experto en retórica. Tu objetivo es generar 7 poemas sobre la palabra: [{palabra}],
FIGURA RETÓRICA OBLIGATORIA: [{figura_nombre}: {figura_def}]. 
Es crucial que respetes la estructura técnica de la figura mencionada.

ESTRUCTURA DE LA RESPUESTA:
Encabezado: ======[{palabra} EN MAYÚSCULAS]
Genera exactamente 7 poemas de 4 versos cada uno.
Separa cada poema con la secuencia: “ññññ”
Todos los poemas deben incluir al menos una vez la palabra.
No uses mayusculas en la palabra {palabra} a menos que sea necesario.
No incluyas notas, comentarios ni introducciones. Solo los poemas.

ENFOQUES SECUENCIALES (Uno para cada poema):
1. Tono: Agotamiento y pesadez.
2. Tono: Enumeración infinita.
3. Tono: Solemne y sagrado.
4. Perspectiva: La acumulación del tiempo.
5. Perspectiva: Elementos de la naturaleza.
6. Estilo: Barroco y recargado.
7. Estilo: Ansiedad urbana.
"""

def leer_palabras(archivo):
    if not os.path.exists(archivo):
        print(f"ERROR: No existe '{archivo}'.")
        return []
    with open(archivo, "r", encoding="utf-8") as f:
        return [linea.strip() for linea in f.readlines() if linea.strip()]

def preparar_carpetas(seleccion):
    if not os.path.exists(CARPETA_SALIDA):
        os.makedirs(CARPETA_SALIDA)
    for figura in seleccion:
        ruta_figura = os.path.join(CARPETA_SALIDA, figura)
        if not os.path.exists(ruta_figura):
            os.makedirs(ruta_figura)

def guardar_organizado(nombre_figura, contenido, nombre_lote):
    carpeta_destino = os.path.join(CARPETA_SALIDA, nombre_figura)
    nombre_limpio = nombre_figura.lower().replace("ó", "o").replace("á", "a").replace("é", "e").replace("í", "i")
    nombre_archivo = f"{nombre_limpio}_{nombre_lote}.txt"
    ruta_completa = os.path.join(carpeta_destino, nombre_archivo)

    with open(ruta_completa, "a", encoding="utf-8") as f:
        f.write(contenido)
        f.write("\n" + "=" * 40 + "\n\n")

def generar_con_rotacion(prompt_final):
    for modelo_actual in MODELOS_DISPONIBLES:
        try:
            chat_completion = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": "Eres un asistente poético experto en figuras retóricas avanzadas."},
                    {"role": "user", "content": prompt_final}
                ],
                model=modelo_actual,
                temperature=0.7,
            )
            return chat_completion.choices[0].message.content, modelo_actual
        except Exception as e:
            error_msg = str(e)
            if "429" in error_msg or "rate limit" in error_msg.lower():
                print(f"   Cuota llena en {modelo_actual}. Cambiando motor...")
                continue
            else:
                print(f"   Error extraño en {modelo_actual}: {error_msg[:30]}...")
                continue
    return None, None

def main():
    nombre_lote = os.path.splitext(ARCHIVO_ENTRADA)[0]
    lista_palabras = leer_palabras(ARCHIVO_ENTRADA)
    if not lista_palabras: return

    figuras_validas = {k: v for k, v in figuras_master.items() if k in FIGURAS_A_GENERAR}
    
    if not figuras_validas:
        print("ERROR: Ninguna de las figuras en FIGURAS_A_GENERAR es válida.")
        return

    preparar_carpetas(figuras_validas.keys())
    print(f"Iniciando Lote: {nombre_lote}")
    print(f"Figuras a procesar: {', '.join(figuras_validas.keys())}")

    for nombre_figura, definicion_figura in figuras_validas.items():
        print(f"\nFIGURA: {nombre_figura.upper()}")
        print("-" * 40)

        for i, palabra in enumerate(lista_palabras, 1):
            prompt_final = prompt_template.format(
                palabra=palabra.upper(),
                figura_nombre=nombre_figura.upper(),
                figura_def=definicion_figura
            )

            print(f"   [{i}/{len(lista_palabras)}] {palabra}...", end="", flush=True)

            texto_generado, modelo_usado = generar_con_rotacion(prompt_final)

            if texto_generado:
                guardar_organizado(nombre_figura, texto_generado, nombre_lote)
                print(f" (vía {modelo_usado})")
                
                if "instant" in modelo_usado:
                    print(" ###### CAMBIAR DE CUENTA, se usa el modelo pequeño #####")
                    time.sleep(1.5)
                else:
                    time.sleep(3)
            else:
                print("FATAL: Todos los modelos fallaron.")
                time.sleep(60)

    print(f"\nLOTE {nombre_lote} TERMINADO")

if __name__ == "__main__":
    main()