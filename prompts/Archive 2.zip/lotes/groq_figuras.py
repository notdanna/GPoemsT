import os
import time
from groq import Groq

# Configuración de API
API_KEY = "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"
client = Groq(api_key=API_KEY)

FIGURAS_A_GENERAR = [
    "Antitésis",
]

MODELOS_DISPONIBLES = [
    "llama-3.3-70b-versatile",
    "llama-3.1-70b-versatile",
    "mixtral-8x7b-32768",
    "gemma2-9b-it"
]

ARCHIVO_ENTRADA = "lote_003.txt"
CARPETA_SALIDA = "Bpoemas_generados"

# Diccionario optimizado con Explicación + Ejemplo para el modelo
figuras_master = {
    "Antitésis": "CONTRASTE FUERTE. Presentar ideas opuestas en versos o frases cercanas. EJEMPLO: 'Es tan corto el amor, y es tan largo el olvido'. DEBE haber un choque claro entre conceptos.",
    "Epífora": "REPETICIÓN FINAL. Repetición de una o varias palabras al final de versos consecutivos. EJEMPLO: 'No digas nada, / no preguntes nada, / no esperes nada'. LA PALABRA FINAL DEBE SER IDÉNTICA.",
    "Anadiplosis": "ENCADENAMIENTO. La última palabra de un verso debe ser la primera del siguiente. EJEMPLO: '...con la mirada. / La mirada que busca...'. CREA UNA CADENA.",
    "Epanadiplosis": "REPETICIÓN EN ESPEJO. El verso debe empezar y terminar con la misma palabra exacta. EJEMPLO: 'Verde que te quiero verde'.",
    "Bimembración": "SIMETRÍA BINARIA. Dividir el verso en dos partes con la misma estructura gramatical. EJEMPLO: 'Cuerpo de mujer, blancas colinas'. DEBE sentirse un equilibrio rítmico de dos miembros.",
    "Políptoton": "VARIACIÓN FLEXIVA. Usar la misma palabra con diferentes accidentes gramaticales (género, número, tiempo). EJEMPLO: '¿Cómo quieres que te quiera si el que quiero que me quiera no me quiere como quiero que me quiera?'.",
    "Quiasmo": "CRUCE ESTRUCTURAL. Repetir ideas de forma cruzada (A-B / B-A). EJEMPLO: 'Ni son todos los que están, ni están todos los que son'.",
    "Correlación": "CORRESPONDENCIA. Vincular elementos en orden. EJEMPLO: 'Gorro, capa, guante / rojo, azul, verde' (donde rojo es el gorro, azul la capa, etc.).",
    "Apóstrofe": "INVOCACIÓN DIRECTA. Interrumpir el discurso para dirigirse con pasión a un ser presente, ausente o abstracto. EJEMPLO: '¡Oh, noche que guiaste!'.",
    "Hipérbaton": "DESORDEN SINTÁCTICO. Alterar el orden lógico de la oración (Sujeto + Verbo + Predicado). EJEMPLO: 'Volverán las oscuras golondrinas en tu balcón sus nidos a colgar'.",
    "Anástrofe": "INVERSIÓN BREVE. Invertir el orden de solo dos palabras consecutivas, usualmente preposición o adjetivo. EJEMPLO: 'Difícil de ver es' en lugar de 'Es difícil de ver'.",
    "Elipsis": "OMISIÓN VOLUNTARIA. Suprimir palabras necesarias para la gramática pero no para el sentido. EJEMPLO: 'Por una mirada, un mundo; por una sonrisa, un cielo'.",
    "Sinestesia": "CRUCE SENSORIAL. Atribuir una sensación a un sentido que no le corresponde. EJEMPLO: 'Suave como un silbido' o 'Amarillo chillón'.",
    "Paranomasia": "JUEGO FONÉTICO. Usar palabras que suenan casi igual pero significan cosas distintas. EJEMPLO: 'Ciego que no ve, sesgo que no cree'.",
    "Diáfora": "REPETICIÓN CON DISTINTO SENTIDO. Usar la misma palabra con significados diferentes en el mismo poema. EJEMPLO: 'Mora que en la morería / se quedó mora' (referencia a etnia y a tardanza).",
    "Calambur": "REAGRUPACIÓN DE SÍLABAS. Modificar el significado al juntar sílabas de forma distinta. EJEMPLO: 'Si el Rey no muere, el Reino muere' o 'Oro parece, plata no es'."
}

prompt_template = """
Eres un poeta experto en retórica técnica. Tu misión principal es aplicar la figura: [{figura_nombre}].

REGLA DE ORO: La figura retórica es el requisito de máxima prioridad. El poema DEBE construirse siguiendo fielmente la técnica explicada:
[{figura_def}]

ESTRUCTURA OBLIGATORIA:
Encabezado: ======[{palabra}]
Genera exactamente 7 poemas de 4 versos cada uno.
Separa cada poema con la secuencia: “ññññ”
Todos los poemas deben incluir al menos una vez la palabra: {palabra}.
No incluyas notas ni introducciones. Solo el encabezado y los poemas.

ENFOQUES SECUENCIALES (Uno para cada poema):
1. Tono: Agotamiento.
2. Tono: Enumeración.
3. Tono: Solemne.
4. Perspectiva: Tiempo.
5. Perspectiva: Naturaleza.
6. Estilo: Barroco.
7. Estilo: Ansiedad urbana.

RECUERDA: Si la figura es una Epífora, repite la palabra al final. Si es una Antítesis, crea contrastes violentos. Si es un Calambur, juega con las sílabas. La técnica debe ser perfecta.
"""

def leer_palabras(archivo):
    if not os.path.exists(archivo):
        print(f"ERROR: No existe '{archivo}'.")
        return []
    with open(archivo, "r", encoding="utf-8") as f:
        return [linea.strip() for linea in f.readlines() if linea.strip()]

def preparar_carpetas(seleccion):
    if not os.path.exists(CARPETA_SALIDA):
        os.makedirs(CARPETA_SALIDA)
    for figura in seleccion:
        ruta_figura = os.path.join(CARPETA_SALIDA, figura)
        if not os.path.exists(ruta_figura):
            os.makedirs(ruta_figura)

def guardar_organizado(nombre_figura, contenido, nombre_lote):
    carpeta_destino = os.path.join(CARPETA_SALIDA, nombre_figura)
    nombre_limpio = nombre_figura.lower().replace("ó", "o").replace("á", "a").replace("é", "e").replace("í", "i")
    nombre_archivo = f"{nombre_limpio}_{nombre_lote}.txt"
    ruta_completa = os.path.join(carpeta_destino, nombre_archivo)
    with open(ruta_completa, "a", encoding="utf-8") as f:
        f.write(contenido)
        f.write("\n" + "=" * 40 + "\n\n")

def generar_con_rotacion(prompt_final):
    for modelo_actual in MODELOS_DISPONIBLES:
        try:
            chat_completion = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": "Eres un asistente experto en métrica y figuras retóricas avanzadas. Tu prioridad es la precisión técnica de la figura solicitada."},
                    {"role": "user", "content": prompt_final}
                ],
                model=modelo_actual,
                temperature=0.4, # Temperatura más baja para mayor rigor técnico
            )
            return chat_completion.choices[0].message.content, modelo_actual
        except Exception as e:
            print(f"   Error en {modelo_actual}, reintentando...")
            continue
    return None, None

def main():
    nombre_lote = os.path.splitext(ARCHIVO_ENTRADA)[0]
    lista_palabras = leer_palabras(ARCHIVO_ENTRADA)
    if not lista_palabras: return

    figuras_validas = {k: v for k, v in figuras_master.items() if k in FIGURAS_A_GENERAR}
    preparar_carpetas(figuras_validas.keys())

    for nombre_figura, definicion_figura in figuras_validas.items():
        print(f"\nPROCESANDO FIGURA: {nombre_figura.upper()}")
        for i, palabra in enumerate(lista_palabras, 1):
            prompt_final = prompt_template.format(
                palabra=palabra.upper(),
                figura_nombre=nombre_figura.upper(),
                figura_def=definicion_figura
            )
            print(f"   [{i}/{len(lista_palabras)}] {palabra}...", end="", flush=True)
            texto_generado, modelo_usado = generar_con_rotacion(prompt_final)
            if texto_generado:
                guardar_organizado(nombre_figura, texto_generado, nombre_lote)
                print(f" OK ({modelo_usado})")
                time.sleep(2)

if __name__ == "__main__":
    main()